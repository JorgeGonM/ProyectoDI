package com.clase;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class AcercadeController {

    @FXML 
    private void cerrarAcercade(ActionEvent event) {

        // Cierra la ventana actual
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        
        stage.close();

        

    }
}
