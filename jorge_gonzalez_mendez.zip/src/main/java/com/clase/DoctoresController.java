package com.clase;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import com.clase.modelo.Doctor;
import com.clase.persistencia.DoctorDAOMySQL;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class DoctoresController implements Initializable{
   
    @FXML 
    private TextField iddoc, apeldoc, nomdoc, movildoc, emaildoc;

    @FXML 
    private ComboBox<String> espedoc;

    @FXML
    private RadioButton coledocsi, coledocno;

    @FXML 
    private Button btnguardardoc, btndeldoc, btnLimpiarDoc, btnBuscarDoc;

    @FXML
    private TableView<Doctor> tablaDoctores;

    @FXML 
    private TableColumn<Doctor, String> coliddoc, colapeldoc, colnomdoc, colmovildoc, colespedoc;
   
    boolean doctorExiste = false;
    private CitasController citasController;

    public void setCitasController(CitasController citasController) {
        this.citasController = citasController;
    }

    @Override 
    public void initialize(URL url, ResourceBundle rb){

        iddoc.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue){
                
            }
        });

        nomdoc.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue){
                String nombre = letrasCapitales(nomdoc.getText());
                nomdoc.setText(nombre);
            }
        });

        apeldoc.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue){
                String apellidos = letrasCapitales(apeldoc.getText());
                apeldoc.setText(apellidos);
            }
        });

        movildoc.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue){
                comprobarMovil();
            }
        });

        emaildoc.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue){
                comprobarEmail();
            }
        });

        cargarEspecialidades();
        

        //Vinculamos las columnas de la tabla con los atributos del modelo Doctor
        coliddoc.setCellValueFactory(new PropertyValueFactory<>("iddoc"));
        colapeldoc.setCellValueFactory(new PropertyValueFactory<>("apeldoc"));
        colnomdoc.setCellValueFactory(new PropertyValueFactory<>("nomdoc"));
        colmovildoc.setCellValueFactory(new PropertyValueFactory<>("movildoc"));
        colespedoc.setCellValueFactory(new PropertyValueFactory<>("espedoc")); 



        cargarDoctores();

        //Carga un doctor al seleccionarlo en la tabla en el formaulario para poder modificarlo o eliminarlo

        tablaDoctores.getSelectionModel().selectedItemProperty().addListener((observable, anterior, nuevo) -> {
            if (nuevo != null) {
                cargarDoctor();
                if (citasController != null) {
                    citasController.cargarDatosDoctor(nuevo);
                }
            }
        });



    }


    @FXML 
    private void cargarEspecialidades(){
        
        // Abrimos el fichero JSON que está dentro de resources
        // usamos la clase de java InputStrem que lee datos en este caso de un fichero

        InputStream is = getClass().getResourceAsStream("/com/clase/data/especialidades.json");

 
        // Leemos el JSON y lo convertimos en un objeto JsonObject
        JsonObject json = JsonParser.parseReader(
                new InputStreamReader(is)
        ).getAsJsonObject();

 
        // Obtenemos el array "provincias" del JSON
        JsonArray especialidades = json.getAsJsonArray("especialidades");

        // Recorremos todas las provincias
        for (var especialidad : especialidades) {

            // Cada elemento del array es un objeto JSON
            JsonObject p = especialidad.getAsJsonObject();

            // Obtenemos el nombre de la provincia
            // y lo añadimos al ComboBox
            espedoc.getItems().add(
                    p.get("nombre").getAsString()
            );
        }
    }

    //Letras Capitales
    private String letrasCapitales(String texto){

        String[] palabras = texto.toLowerCase().trim().split("\\s+");
        StringBuilder resultado = new StringBuilder();

        for(String palabra: palabras){
            if (!palabra.isEmpty()) {
                resultado.append(Character.toUpperCase(palabra.charAt(0))).append(palabra.substring(1)).append(" ");
            }
        }

        return resultado.toString().trim();

    }

    //Comprobar móvil
    @FXML
    private void comprobarMovil(){
        String movil = movildoc.getText().trim().toUpperCase();
        if(movil.isEmpty())
            return;

        if(validarMovil(movil)){
            movildoc.setStyle("");
            movildoc.setText(movil);
        }else{
            movildoc.setStyle("-fx-border-color: red;");
            movildoc.setText("");
        }
        
    }

    @FXML
    private boolean validarMovil(String movil){
        
        return movil.matches("[67][0-9]{8}");
    }
     

    //Comprobar email
    @FXML
    private void comprobarEmail(){
        String email = emaildoc.getText().trim();
        if(email.isEmpty())
            return;

        if(validarEmail(email)){
            emaildoc.setStyle("");
            emaildoc.setText(email);
        }else{
            emaildoc.setStyle("-fx-border-color: red;");
            emaildoc.setText("");
        }
        
    }

    @FXML
    private boolean validarEmail(String email){
        
        return email.matches("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$");    
    
    }


     @FXML
    private void guardarDoctor(){

    
        String id = iddoc.getText();
        String apellidos = apeldoc.getText();
        String nombre = nomdoc.getText();

        String telefono = movildoc.getText();
        String email = emaildoc.getText();
        Boolean colegiado;
        if(coledocsi.isSelected()){
            colegiado = true;
        }else{
            colegiado = false;
        }
        String especialidad = espedoc.getValue();

        //Creamos el objeto paciente
        Doctor doctor = new Doctor(id, apellidos, nombre, telefono, email, colegiado, especialidad);


        if(doctorExiste){
            

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmación");
            alert.setHeaderText(null);
            alert.setContentText("¿Desea modificar el doctor?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                //Si el doctor ya existe, lo actualizamos en la BBDD
                DoctorDAOMySQL dao = new DoctorDAOMySQL();
                dao.modificarDoctor(iddoc.getText(), doctor);

                limpiarCampos();

                //Alerta
                Alert alert3 = new Alert(Alert.AlertType.INFORMATION);
                alert3.setTitle("Información");
                alert3.setHeaderText(null);
                alert3.setContentText("Doctor modificado guardado");
                alert3.showAndWait();

            }else{
                return;
            }


            doctorExiste = false;
        }else{
            

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmación");
            alert.setHeaderText(null);
            alert.setContentText("¿Desea guardar el doctor?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {

                //Si el doctor no existe, lo guardamos en la BBDD
                DoctorDAOMySQL dao = new DoctorDAOMySQL();
                dao.guardarDoctor(doctor);

                limpiarCampos();


                //Alerta
                Alert alert3 = new Alert(Alert.AlertType.INFORMATION);
                alert3.setTitle("Información");
                alert3.setHeaderText(null);
                alert3.setContentText("Doctor guardado correctamente");
                alert3.showAndWait();

            }else{
                return;
            }

        }

        //Recargamos la tabla de doctores
        cargarDoctores();


        System.out.println("======== DOCTOR =========");
        System.err.println("ID: " + id);
        System.out.println("Apellidos: " + apellidos);        
        System.out.println("Nombre: " + nombre);        
        System.out.println("Teléfono: " + telefono);        
        System.out.println("Email: " + email);        
        System.out.println("Colegiado: " + colegiado);        
        System.out.println("Especialidad: " + especialidad);
        System.out.println("===========================");        


    } 


    //Cargar doctores en la tabla
    @FXML 
    private void cargarDoctores(){

        //Creamos el DAO
        DoctorDAOMySQL dao = new DoctorDAOMySQL();

        //Obetenemos los doctores de la base de datos
        List<Doctor> doctores = dao.cargarDoctores();

        //Los mostramos en la tabla
        tablaDoctores.getItems().setAll(doctores);

    }


    @FXML 
    private void eliminarDoctor(){

       Doctor seleccionado = tablaDoctores.getSelectionModel().getSelectedItem();

        if(seleccionado == null) {
            return;
        }

        

        //Alerta
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Aviso");
        alert.setHeaderText(null);
        alert.setContentText("¿Desea eliminar el doctor?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            DoctorDAOMySQL dao = new DoctorDAOMySQL();
            dao.eliminarDoctor(seleccionado.getIddoc());
            Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
            alert2.setTitle("Aviso");
            alert2.setHeaderText(null);
            alert2.setContentText("Doctor dado de baja correctamente");

        }else{
            return;
        }


        //Recargamos la tabla de doctores
        cargarDoctores();
        limpiarCampos();

    }


    @FXML 
    private void cargarDoctor(){

        coledocsi.setSelected(false);
        coledocno.setSelected(false);
        Doctor doctorSelect = tablaDoctores.getSelectionModel().getSelectedItem();

        if(doctorSelect == null){
            return;
        } else {
            doctorExiste = true;
        }

        iddoc.setText(doctorSelect.getIddoc());

        DoctorDAOMySQL dao = new DoctorDAOMySQL();

        Doctor doctor = dao.buscarDoctor(doctorSelect.getIddoc());

        if(doctor ==null){
            System.out.println("No se ha encontrado el doctor con la especialidad: " + doctorSelect.getEspedoc());
            return;
        }

        apeldoc.setText(doctor.getApeldoc());
        nomdoc.setText(doctor.getNomdoc());
        movildoc.setText(doctor.getMovildoc());
        emaildoc.setText(doctor.getEmaildoc());
        if(doctor.getColedoc() != null){
            if(doctor.getColedoc()){
                coledocsi.setSelected(true);
            }else{
                coledocno.setSelected(true);
            }
        }
        espedoc.setValue(doctor.getEspedoc());
    }


    /*@FXML 
    private void buscadocsPorEspeceialidad(){

        DoctorDAOMySQL dao = new DoctorDAOMySQL();

        List<Doctor> doctores = dao.cargarDoctores()
    }
*/


    @FXML 
    private void buscaDocEspec(){
        String especialidad = espedoc.getValue();
        if (especialidad == null || especialidad.isBlank()) {
            cargarDoctores();
            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Aviso");
            alert2.setHeaderText(null);
            alert2.setContentText("No existen doctores con esa especialidad el la BBDD");
            alert2.showAndWait();
            return;
        }

        DoctorDAOMySQL dao = new DoctorDAOMySQL();
        List<Doctor> doctores = dao.buscaDocEspec(especialidad);

        if(doctores ==null){
            return;
        }


        doctorExiste = false;
        tablaDoctores.getSelectionModel().clearSelection();
        tablaDoctores.getItems().setAll(doctores);

        
    }



    @FXML
    private void limpiarCampos() {
        doctorExiste = false;
        iddoc.clear();
        apeldoc.clear();
        nomdoc.clear();
        movildoc.clear();
        emaildoc.clear();
        espedoc.getSelectionModel().clearSelection();
        coledocsi.setSelected(false);
        coledocno.setSelected(false);
        tablaDoctores.getSelectionModel().clearSelection();
    } 


    
    


}
